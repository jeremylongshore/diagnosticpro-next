import"./CWj6FrbW.js";import"./CQ1Qo5sC.js";import{g as i,i as n,j as p}from"./67ZfzKJv.js";import{I as l,s as d}from"./C7dBi20r.js";import{l as m,s as $}from"./BTXKou4E.js";function b(s,e){const t=m(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.445.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335"}],["path",{d:"m9 11 3 3L22 4"}]];l(s,$({name:"circle-check-big"},()=>t,{get iconNode(){return r},children:(a,f)=>{var o=i(),c=n(o);d(c,e,"default",{}),p(a,o)},$$slots:{default:!0}}))}export{b as C};
