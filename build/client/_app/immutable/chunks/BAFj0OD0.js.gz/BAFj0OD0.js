import"./CWj6FrbW.js";import"./CQ1Qo5sC.js";import{g as n,i as p,j as c}from"./67ZfzKJv.js";import{I as d,s as l}from"./C7dBi20r.js";import{l as m,s as $}from"./BTXKou4E.js";function y(t,s){const a=m(s,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.445.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"}]];d(t,$({name:"shield"},()=>a,{get iconNode(){return e},children:(r,f)=>{var o=n(),i=p(o);l(i,s,"default",{}),c(r,o)},$$slots:{default:!0}}))}export{y as S};
