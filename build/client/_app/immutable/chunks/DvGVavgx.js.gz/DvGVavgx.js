import"./CWj6FrbW.js";import"./CQ1Qo5sC.js";import{g as n,i as p,j as l}from"./67ZfzKJv.js";import{I as m,s as c}from"./C7dBi20r.js";import{l as d,s as $}from"./BTXKou4E.js";function x(s,t){const r=d(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.445.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"}]];m(s,$({name:"mail"},()=>r,{get iconNode(){return e},children:(a,f)=>{var o=n(),i=p(o);c(i,t,"default",{}),l(a,o)},$$slots:{default:!0}}))}export{x as M};
